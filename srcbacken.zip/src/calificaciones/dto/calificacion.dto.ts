export class CalificacionDto {
  readonly estudianteId: string;
  readonly materia: string;
  readonly calificacion: number;
  readonly evaluacion: string;
}
