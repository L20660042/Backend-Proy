import { Types } from 'mongoose';

/** Para usar ObjectId en todos los schemas y DTOs */
export type ObjectId = Types.ObjectId | string;
