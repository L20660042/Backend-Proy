import { Controller, Post, Get, Body, Param, Put } from '@nestjs/common';
import { CalificacionesService } from './calificaciones.service';

@Controller('calificaciones')
export class CalificacionesController {
  constructor(private readonly calificacionesService: CalificacionesService) {}

  // Crear una calificación
  @Post()
  async crear(@Body() calificacionDto: any) {
    return this.calificacionesService.crearCalificacion(calificacionDto);
  }

  // Obtener las calificaciones de un estudiante
  @Get(':estudianteId')
  async obtener(@Param('estudianteId') estudianteId: string) {
    return this.calificacionesService.obtenerCalificacionesPorEstudiante(estudianteId);
  }

  // Actualizar una calificación
  @Put(':id')
  async actualizar(@Param('id') id: string, @Body() calificacionDto: any) {
    return this.calificacionesService.actualizarCalificacion(id, calificacionDto);
  }
}
